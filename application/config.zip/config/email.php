<?php
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'example.com';
$config['smtp_user'] = 'user';
$config['smtp_user_name'] = 'Im a User';
$config['smtp_pass'] = 'password';
$config['smtp_timeout'] = '30';
$config['charset'] = 'UTF-8';
$config['wordwrap'] = true;
$config['debug'] = false;